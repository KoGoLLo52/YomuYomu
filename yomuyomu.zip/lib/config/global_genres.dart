Map<String, bool> genreFilterStatus = {
  "Action": false,
  "Comedy": false,
  "Drama": false,
  "Fantasy": false,
  "Horror": false,
  "Romance": false,
  "Sci-Fi": false,
  "Slice of Life": false,
};